Cách mở:
## Import database:
- Mở ứng dụng XAMPP, chọn start Apache và MySQL
- Truy cập phpMyAdmin bằng cách nhấn Admin bên cạnh nút Start MySQL
- Chọn import -> Chọn database webphim1.sql -> Import
- Tới trình duyệt và gõ localhost:8080/Webphim
- Sau khi dùng xong, tắt chương trình ở IDE và Stop Apache, MySQL
Lưu ý:
- Tài khoản mật khẩu đăng nhập admin là: admin123456 admin123456
- User có thể tùy ý tạo user để login
Thầy cô nên vào trang login.php đói vs user
admin/login.php đối vs admin