<div class="footer row">
    <div class="col-4 footer-branch">
        <img src="./logo/Unionlogo.svg" alt="" class="footer-branch-logo">
        <div class="footer-branch-name text-white">TPNK PHIM</div>
    </div>
    <div class="col-4 footer-copyright">
        <div class="footer-copyright-top text-white">
            Source Code Copy Right By TPNK Final Exam.
        </div>
        <div class="footer-copry-bottom text-white">
            info@tpnk.com <br>
            +33879222xx
        </div>
    </div>
    <div class="col-4 footer-social">
        <div class="social-logo-component">
            <div>
                <img src="./logo/gmail.png" alt="" class="footer-social-logo">
                <div class="social-name text-white">Gmail</div>
            </div>
        </div>
        <div class="social-logo-component">
            <div>
                <img src="./logo/facebook.png" alt="" class="footer-social-logo">
                <div class="social-name text-white">Facebook</div>
            </div>
        </div>
        <div class="social-logo-component">
            <div>
                <img src="./logo/twitter.png" alt="" class="footer-social-logo">
                <div class="social-name text-white">Twitter</div>
            </div>
        </div>
    </div>
</div>